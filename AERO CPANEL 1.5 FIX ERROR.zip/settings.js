/* 
BASE BY SKYZO
SC INI ENC, JIKA INGIN BELI VERSI NO ENC CHAT DEVELOPER
=============CONTACT===============
          WA:6287858125785
          TELE:t.me/Kyyslow
          YT:KYY NEV
          CH¹:https://whatsapp.com/channel/0029VakAHSOKLaHnxS6tII0i
          CH²:https://whatsapp.com/channel/0029VaojVzr3LdQWWTEIKr13
====================================
FOLLOW CH KYY NEV UNTUK UPDATE SC AERO DAN
JANGAN HAPUS CREDIT INI!
*/

const fs = require('fs');
const chalk = require('chalk');

// Settings Bot 
global.owner = '6287822082924'
global.versi = "0.1.5"
global.namaOwner = "TAKA DEV"
global.packname = 'TAKA CREAT PANEL'
global.botname = 'TAKA CPANEL'
global.botname2 = 'TAKA BOT'

global.tempatDB = 'database.json' // Jangan ubah
global.pairing_code = true // Jangan ubah

// Settings Api Panel Pterodactyl Server 1
global.egg = "15" // gausah diubah
global.nestid = "5" // gausah diubah
global.loc = "1" // gausah diubah
global.domain = "-https://kontolkuda.rendzzganteng.my.id"
global.apikey = "-ptla_zx4OlgLffg7QQsmNwQgecd66PYNAnmWaxQQUA37wR2M" //ptla
global.capikey = "-ptlc_DrezDZ6ui0KbyraAawj7r3V4tqRgMvHpT6mSAW22DK5" //ptlc

// JANGAN DIHAPUS MESKIPUN GAK GUNA WKWKWKWKWK
global.mess = {
	owner: "* *Akses Ditolak*\nFitur ini hanya untuk owner bot!",
	admin: "* *Akses Ditolak*\nFitur ini hanya untuk admin grup!",
	botAdmin: "* *Akses Ditolak*\nFitur ini hanya untuk ketika bot menjadi admin!",
	group: "* *Akses Ditolak*\nFitur ini hanya untuk dalam grup!",
	private: "* *Akses Ditolak*\nFitur ini hanya untuk dalam private chat!",
	prem: "* *Akses Ditolak*\nFitur ini hanya untuk user premium!",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})